import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.navigateToUrl('https://craferia.com/')

WebUI.click(findTestObject('Object Repository/Caferia_login_page_OR/a_My account'))

WebUI.click(findTestObject('Object Repository/Caferia_login_page_OR/body_Skip to navigationSkip to contentMy ac_95af43'))

WebUI.setEncryptedText(findTestObject('Object Repository/Caferia_login_page_OR/input__password'), 'VHdW2eXQECJ992xMMRoGQA==')

WebUI.click(findTestObject('Object Repository/Caferia_login_page_OR/button_Log in'))

WebUI.rightClick(findTestObject('Object Repository/Caferia_login_page_OR/li_Error The username swetha is not registe_33f1d8'))

WebUI.verifyElementText(findTestObject('Object Repository/Caferia_login_page_OR/li_Error The username swetha is not registe_33f1d8'), 
    'Error: The username swetha is not registered on this site. If you are unsure of your username, try your email address instead.')

WebUI.verifyCheckpoint(findCheckpoint('Checkpoints/Craferia/Craferia'), false)

