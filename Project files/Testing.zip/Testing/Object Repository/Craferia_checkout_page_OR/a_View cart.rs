<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_View cart</name>
   <tag></tag>
   <elementGuidId>bad0e145-9eed-4560-93d5-bb7faf344ed9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.woocommerce-message > a.button.wc-forward</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='content']/div/div/div/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>fa4b3501-637b-4919-b1a5-396db153033e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://craferia.com/cart/</value>
      <webElementGuid>7c9cf656-f622-40ce-b1d5-7265c53e4aca</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>button wc-forward</value>
      <webElementGuid>d748c40c-a6d1-472a-bfe7-331353b8f55e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>View cart</value>
      <webElementGuid>56914658-6d9f-4a9e-a752-bec26174bf66</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;content&quot;)/div[@class=&quot;col-full&quot;]/div[@class=&quot;woocommerce&quot;]/div[@class=&quot;woocommerce-message&quot;]/a[@class=&quot;button wc-forward&quot;]</value>
      <webElementGuid>5832fe1a-1e7d-4ea2-a618-c193c9dab260</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='content']/div/div/div/a</value>
      <webElementGuid>8171930f-7d07-4233-bbe0-6cb7590c3ff5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>(//a[contains(text(),'View cart')])[2]</value>
      <webElementGuid>2bb5ae9c-33e0-466e-8b28-e6b88dcfcc2d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='/'])[4]/following::a[1]</value>
      <webElementGuid>31ea8b83-6e82-4224-a116-2050b37d3cd1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='OFF'])[1]/preceding::a[6]</value>
      <webElementGuid>b8d8c7b0-0952-4e09-9f03-dfe69a4482c7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='SALE'])[1]/preceding::a[6]</value>
      <webElementGuid>96e94da4-128c-410b-9715-e58f7a403e5c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, 'https://craferia.com/cart/')])[5]</value>
      <webElementGuid>e5b22e5b-5911-437e-a4d7-2556153f6379</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div/a</value>
      <webElementGuid>66fd4e16-488c-4b07-a99d-ff08da5876e2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://craferia.com/cart/' and (text() = 'View cart' or . = 'View cart')]</value>
      <webElementGuid>41ee4a7a-0c37-44f3-999c-02f9428d40c5</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
