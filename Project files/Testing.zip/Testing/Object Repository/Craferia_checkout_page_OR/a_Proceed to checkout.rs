<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Proceed to checkout</name>
   <tag></tag>
   <elementGuidId>77f770b5-0116-4318-9d98-3238466ca6d2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a.checkout-button.button.alt.wc-forward</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//article[@id='post-7']/div/div/div[2]/div/div/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>26367635-4c09-47e9-8ae0-1a176be9be1f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://craferia.com/checkout/</value>
      <webElementGuid>4a7f6029-fe72-4ec3-b8fd-f259808ffa1d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>checkout-button button alt wc-forward</value>
      <webElementGuid>24e773ef-68ee-47d6-a013-f8b41718efca</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
	Proceed to checkout</value>
      <webElementGuid>c4c7ea48-f4f2-4b16-a8e8-a96397d78740</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;post-7&quot;)/div[@class=&quot;entry-content&quot;]/div[@class=&quot;woocommerce&quot;]/div[@class=&quot;cart-collaterals&quot;]/div[@class=&quot;cart_totals&quot;]/div[@class=&quot;wc-proceed-to-checkout&quot;]/a[@class=&quot;checkout-button button alt wc-forward&quot;]</value>
      <webElementGuid>d221b826-5911-4540-a961-18440877b847</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//article[@id='post-7']/div/div/div[2]/div/div/a</value>
      <webElementGuid>adc86993-fa6c-4592-b9f7-965bfacf6386</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Proceed to checkout')]</value>
      <webElementGuid>0300648a-2d9b-40f7-a5bb-1057775eff70</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='₹'])[6]/following::a[1]</value>
      <webElementGuid>cc2f85e0-a90d-4a53-b99a-312a19fc78d6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Total'])[1]/following::a[1]</value>
      <webElementGuid>1ca6bd57-8bac-4d83-9d9e-18b2ec257298</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Get in touch'])[1]/preceding::a[1]</value>
      <webElementGuid>73e492ba-a846-41d1-adbe-a250b661ef91</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Address'])[1]/preceding::a[1]</value>
      <webElementGuid>e0c84099-396f-4761-88c6-072de96c64e7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Proceed to checkout']/parent::*</value>
      <webElementGuid>dab3d21c-11cb-432b-b854-451d105354d5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, 'https://craferia.com/checkout/')])[2]</value>
      <webElementGuid>a2d9a56d-1f12-4872-bf34-362071b594df</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/a</value>
      <webElementGuid>696fe384-e389-4215-a4da-8f8fa469757b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://craferia.com/checkout/' and (text() = '
	Proceed to checkout' or . = '
	Proceed to checkout')]</value>
      <webElementGuid>26ffc90c-2a05-4c0a-9efe-12cefad3b5f7</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
