<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Wall hanging (107)</name>
   <tag></tag>
   <elementGuidId>b6b7fcd7-f9c5-4196-af35-bfd3bf9a6140</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//main[@id='main']/ul/li[3]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>de960c22-eb74-4b3b-8202-fec50aaa4adf</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-label</name>
      <type>Main</type>
      <value>Visit product category Wall hanging</value>
      <webElementGuid>09762baa-cb52-498f-ab1b-b7ed775f83c0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://craferia.com/wall-hanging/</value>
      <webElementGuid>6a0af506-8707-472d-935f-32def8d94681</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>		
			Wall hanging (107)		
		</value>
      <webElementGuid>cf04af0e-05c1-4986-a0a1-089cb21996e9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;main&quot;)/ul[@class=&quot;products columns-4&quot;]/li[@class=&quot;product-category product&quot;]/a[1]</value>
      <webElementGuid>492d258f-8d6b-4ae2-9c18-02a4689cc722</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//main[@id='main']/ul/li[3]/a</value>
      <webElementGuid>0bc17335-0566-46fe-ae34-24fd389f29eb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='(10)'])[1]/following::a[1]</value>
      <webElementGuid>9b01e0b1-8798-4ef0-909b-8120a7b7ecc9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, 'https://craferia.com/wall-hanging/')])[3]</value>
      <webElementGuid>d4688dd2-ba00-4a66-b84e-20c43b9d359b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//main/ul/li[3]/a</value>
      <webElementGuid>c7bd9c33-7175-49ee-b765-42e368b971bf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://craferia.com/wall-hanging/' and (text() = '		
			Wall hanging (107)		
		' or . = '		
			Wall hanging (107)		
		')]</value>
      <webElementGuid>7cc3ce10-b7d2-4bde-89fb-12e6a86b3745</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
