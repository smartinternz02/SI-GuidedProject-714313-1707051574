<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Return to shop</name>
   <tag></tag>
   <elementGuidId>390bb54e-4be0-4a87-99fc-ac8cc437f211</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a.button.wc-backward</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//article[@id='post-7']/div/div/p/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>bd32b807-592c-410f-99b0-e60050543b4a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>button wc-backward</value>
      <webElementGuid>d9a4437a-c674-4e8a-965d-57da72d1c4f5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://craferia.com/</value>
      <webElementGuid>9c74bcbe-8152-4640-9a01-c4681a67d2ba</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
			Return to shop		</value>
      <webElementGuid>b7057bc7-4d96-4d80-8a8c-466351b7637a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;post-7&quot;)/div[@class=&quot;entry-content&quot;]/div[@class=&quot;woocommerce&quot;]/p[@class=&quot;return-to-shop&quot;]/a[@class=&quot;button wc-backward&quot;]</value>
      <webElementGuid>d68300b6-50b0-4faf-a730-b1e667529975</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//article[@id='post-7']/div/div/p/a</value>
      <webElementGuid>90ce50cd-5424-45c3-9bb6-ccf209fb3882</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Return to shop')]</value>
      <webElementGuid>e8cfd674-9211-48a0-885b-1a2b566f6020</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Your cart is currently empty.'])[1]/following::a[1]</value>
      <webElementGuid>14317001-38d5-4c48-ac91-4e5696bb9d61</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Cart'])[2]/following::a[1]</value>
      <webElementGuid>93a3cbcb-e85e-4cc7-bc44-e1ed6793c7a9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Get in touch'])[1]/preceding::a[1]</value>
      <webElementGuid>70ea842d-4220-4f72-a996-26207f7bb842</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Address'])[1]/preceding::a[1]</value>
      <webElementGuid>19b539ed-370c-45c3-b642-54ee80ad40aa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Return to shop']/parent::*</value>
      <webElementGuid>454263a4-2b1b-4f11-8f56-07ceef92836c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, 'https://craferia.com/')])[122]</value>
      <webElementGuid>418a4fad-310c-4857-9b3c-051f8c9a3b3b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p/a</value>
      <webElementGuid>fca835f8-be10-4c99-bd39-1dd56e2c4493</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://craferia.com/' and (text() = '
			Return to shop		' or . = '
			Return to shop		')]</value>
      <webElementGuid>5feb4c7c-c792-4bb0-9cd3-e812f4008f60</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
