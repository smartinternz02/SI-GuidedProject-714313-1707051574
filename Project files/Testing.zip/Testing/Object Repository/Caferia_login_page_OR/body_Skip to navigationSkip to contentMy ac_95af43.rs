<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>body_Skip to navigationSkip to contentMy ac_95af43</name>
   <tag></tag>
   <elementGuidId>a71713ff-a170-4870-a8fa-23d5c4c33355</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//body</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>body.page-template-default.page.page-id-9.wp-custom-logo.wp-embed-responsive.theme-storefront.woocommerce-account.woocommerce-page.woocommerce-demo-store.woocommerce-js.woocommerce-multi-currency-INR.storefront-full-width-content.storefront-secondary-navigation.storefront-align-wide.left-sidebar.woocommerce-active.sf-input-focused</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>body</value>
      <webElementGuid>fef65c31-2575-44a8-aac7-acbaa0882173</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>page-template-default page page-id-9 wp-custom-logo wp-embed-responsive theme-storefront woocommerce-account woocommerce-page woocommerce-demo-store woocommerce-js woocommerce-multi-currency-INR storefront-full-width-content storefront-secondary-navigation storefront-align-wide left-sidebar woocommerce-active sf-input-focused</value>
      <webElementGuid>0b722d32-6468-43ab-9184-a6d8c2119c16</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>




	
	

				Skip to navigation
		Skip to content
				
					
					
				My account
Checkout
Cart
			
						
				
	Search for:
	
	Search
	

			
					
		Menu
			Home Decor – Items &amp; Gifts

	Showpieces &amp; Figurines
	
		Musical Showpiece
		Spiritual figurines
		Vintage Decor
		Table Organizer
		Collectibles
	

	Wall Decor
	
		Wall hanging
		Spiritual Wall hanging
		Wall Art
		Wall panels
	

	Home Accents
	
		Photo frame
		Diffuser / Burner
	

	Lamps &amp; Lightings
	Clock
	Key Holders


Handmade Furnitures

	Bamboo Furniture
	
		Bamboo Chair
		Bamboo Mudha
		Bamboo Tables
		Bamboo Shelf / Rack
	

	Bamboo Laundry &amp; Organizer Baskets
	Natural Mudha
	Pidha stools
	Iron Stools Frame
	Cane Baskets
	Sofa chair / Long chair
	Wooden Furnitures


Cane Furniture
Outdoor Furniture
Hotel &amp; Restaurant Furniture
Mudha

	Mudha Stools
	Mudha chairs
	Mudha Table


Furnishings

	Cushions
	Placemats &amp; Runners
	Bedsheets
	
		Single Bedsheets
		Double Bedsheet
	

	Blankets &amp; Quilts
	Tapestry
	
		Single Tapestry
		Round Tapestry
		Double Tapestry
	

	Bamboo Storage Basket and Utility Baskets


Ladies Bags

	handbags
	Shoulder bags
	Sling bags
	clutches
	Combo Bags
	mobile pouch / potli bag


Under 500
Home Decor – Items &amp; GiftsExpand child menu

	Showpieces &amp; FigurinesExpand child menu
	
		Musical Showpiece
		Spiritual figurines
		Vintage Decor
		Table Organizer
		Collectibles
	

	Wall DecorExpand child menu
	
		Wall hanging
		Spiritual Wall hanging
		Wall Art
		Wall panels
	

	Home AccentsExpand child menu
	
		Photo frame
		Diffuser / Burner
	

	Lamps &amp; Lightings
	Clock
	Key Holders


Handmade FurnituresExpand child menu

	Bamboo FurnitureExpand child menu
	
		Bamboo Chair
		Bamboo Mudha
		Bamboo Tables
		Bamboo Shelf / Rack
	

	Bamboo Laundry &amp; Organizer Baskets
	Natural Mudha
	Pidha stools
	Iron Stools Frame
	Cane Baskets
	Sofa chair / Long chair
	Wooden Furnitures


Cane Furniture
Outdoor Furniture
Hotel &amp; Restaurant Furniture
MudhaExpand child menu

	Mudha Stools
	Mudha chairs
	Mudha Table


FurnishingsExpand child menu

	Cushions
	Placemats &amp; Runners
	BedsheetsExpand child menu
	
		Single Bedsheets
		Double Bedsheet
	

	Blankets &amp; Quilts
	TapestryExpand child menu
	
		Single Tapestry
		Round Tapestry
		Double Tapestry
	

	Bamboo Storage Basket and Utility Baskets


Ladies BagsExpand child menu

	handbags
	Shoulder bags
	Sling bags
	clutches
	Combo Bags
	mobile pouch / potli bag


Under 500
		
				
			
										
								₹0.00 0 items
			
		
					
			
				

	No products in the cart.


			
		
			
	

	Handicrafts / My account
	
		

		
	
		

			                        
                                                        
                                
                                    
                                
                            
                        
                    

			
			My account		
				
			

		Login

		

			
			
				Username or email address *
							
			
				Password *
				
			

			
			
				
					 Remember me
				
								Log in
			
			
				Lost your password?
			

			
		



					
		

		
	


		
	

	
	
		

							
									
						
Get in touch
 Address :
SRS 110, Nasirpur Rd, near Palam, near Dwarka, Main Road, New Delhi, Delhi 110045

 E-mail id info@craferia.com 
 Call +91 8373915568 ,+91 9354367361					
											
						
INFORMATION


About Us 



Contact us 



Privacy Policy 



Term &amp; Condition

					
											
						
Useful Links


Blog 



Mudha Furnitures 



Corporate Gifts

					
											
						
Follow us

Facebook

Instagram

YouTube

Google

Pinterest
					
									
						
			© Handicrafts Online, Indian Handicraft Items, Handmade in India - Craferia 2024
							
				Built with Storefront &amp; WooCommerce.					
				
			
									
						My Account					
									
						Search			
				
	Search for:
	
	Search
	

			
								
									
												Cart				0
			
		
							
							
		
		
		
	

	


.br_alabel .br_tooltip{display:none;}
                .br_alabel.berocket_alabel_id_27820 > span {
                color: white; display: flex; display: -webkit-box;
display: -ms-flexbox; position: relative; right: 0;text-align: center;
                }
                .br_alabel.berocket_alabel_id_27820 > span i.template-i-before {
                display: block;height: 0;position: absolute;width: 0;
                }
                .br_alabel.berocket_alabel_id_27820 > span i.template-i {
                background-color: transparent;display: block;line-height: 30px;position: absolute;z-index: 99;
                }
                .br_alabel.berocket_alabel_id_27820 > span i.template-i-after {
                display: block;height: 0;position: absolute;width: 0;
                }
                .br_alabel.berocket_alabel_id_27820 > span i.template-span-before {
                display: block;height: 0;position: absolute;width: 0;
                }div.br_alabel.berocket_alabel_id_27820{top:-10px;left:-10px;z-index:500;}div.br_alabel.berocket_alabel_id_27820 > span{height: 35px;width: 60px;background-color:#d03813;color:#ffffff;border-radius:3px;line-height:1.2em;font-size:14px;padding-left: 0px; padding-right: 0px; padding-top: 1px; padding-bottom: 0px; margin-left: -10px; margin-right: -10px; margin-top: -10px; margin-bottom: -10px; }
                .br_alabel.berocket_alabel_id_27823 > span {
                color: white; display: flex; display: -webkit-box;
display: -ms-flexbox; position: relative; right: 0;text-align: center;
                }
                .br_alabel.berocket_alabel_id_27823 > span i.template-i-before {
                display: block;height: 0;position: absolute;width: 0;
                }
                .br_alabel.berocket_alabel_id_27823 > span i.template-i {
                background-color: transparent;display: block;line-height: 30px;position: absolute;z-index: 99;
                }
                .br_alabel.berocket_alabel_id_27823 > span i.template-i-after {
                display: block;height: 0;position: absolute;width: 0;
                }
                .br_alabel.berocket_alabel_id_27823 > span i.template-span-before {
                display: block;height: 0;position: absolute;width: 0;
                }div.br_alabel.berocket_alabel_id_27823{top:-10px;z-index:500;}div.br_alabel.berocket_alabel_id_27823 > span{height: 29px;width: 55px;background-color:#d03813;color:#ffffff;border-radius:3px;line-height:0.9em;font-size:14px;padding-left: 0px; padding-right: 0px; padding-top: 0px; padding-bottom: 0px; margin-left: auto; margin-right: auto;margin-top: -32px; margin-bottom: 0px; }
                .br_alabel.berocket_alabel_id_28035 > span {
                color: white; display: flex; display: -webkit-box;
display: -ms-flexbox; position: relative; right: 0;text-align: center;
                }
                .br_alabel.berocket_alabel_id_28035 > span i.template-i-before {
                display: block;height: 0;position: absolute;width: 0;
                }
                .br_alabel.berocket_alabel_id_28035 > span i.template-i {
                background-color: transparent;display: block;line-height: 30px;position: absolute;z-index: 99;
                }
                .br_alabel.berocket_alabel_id_28035 > span i.template-i-after {
                display: block;height: 0;position: absolute;width: 0;
                }
                .br_alabel.berocket_alabel_id_28035 > span i.template-span-before {
                display: block;height: 0;position: absolute;width: 0;
                }div.br_alabel.berocket_alabel_id_28035{top:-10px;right:-10px;z-index:500;}div.br_alabel.berocket_alabel_id_28035 > span{height: 30px;width: 92px;background-color:#f2c51f;color:#ffffff;border-radius:3px;line-height:1.2em;font-size:12px;padding-left: 0px; padding-right: 0px; padding-top: 0px; padding-bottom: 0px; margin-left: -10px; margin-right: -10px; margin-top: -10px; margin-bottom: -10px; }- Free shipping is now available for all purchases of *CANE FURNITURE  items Dismiss{&quot;@context&quot;:&quot;https:\/\/schema.org\/&quot;,&quot;@type&quot;:&quot;BreadcrumbList&quot;,&quot;itemListElement&quot;:[{&quot;@type&quot;:&quot;ListItem&quot;,&quot;position&quot;:1,&quot;item&quot;:{&quot;name&quot;:&quot;Handicrafts&quot;,&quot;@id&quot;:&quot;https:\/\/craferia.com&quot;}},{&quot;@type&quot;:&quot;ListItem&quot;,&quot;position&quot;:2,&quot;item&quot;:{&quot;name&quot;:&quot;My account&quot;,&quot;@id&quot;:&quot;https:\/\/craferia.com\/my-account\/&quot;}}]}
	
		
		
							
						×
					
	

	
		(function () {
			var c = document.body.className;
			c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
			document.body.className = c;
		})();
	
	

var wc_add_to_cart_params = {&quot;ajax_url&quot;:&quot;\/wp-admin\/admin-ajax.php&quot;,&quot;wc_ajax_url&quot;:&quot;\/?wc-ajax=%%endpoint%%&quot;,&quot;i18n_view_cart&quot;:&quot;View cart&quot;,&quot;cart_url&quot;:&quot;https:\/\/craferia.com\/cart\/&quot;,&quot;is_cart&quot;:&quot;&quot;,&quot;cart_redirect_after_add&quot;:&quot;no&quot;};





var woocommerce_params = {&quot;ajax_url&quot;:&quot;\/wp-admin\/admin-ajax.php&quot;,&quot;wc_ajax_url&quot;:&quot;\/?wc-ajax=%%endpoint%%&quot;};



var wc_cart_fragments_params = {&quot;ajax_url&quot;:&quot;\/wp-admin\/admin-ajax.php&quot;,&quot;wc_ajax_url&quot;:&quot;\/?wc-ajax=%%endpoint%%&quot;,&quot;cart_hash_key&quot;:&quot;wc_cart_hash_b3b9d17cdf5b4420c5a61701c182be0d&quot;,&quot;fragment_name&quot;:&quot;wc_fragments_b3b9d17cdf5b4420c5a61701c182be0d&quot;,&quot;request_timeout&quot;:&quot;5000&quot;};



var storefrontScreenReaderText = {&quot;expand&quot;:&quot;Expand child menu&quot;,&quot;collapse&quot;:&quot;Collapse child menu&quot;};








id(&quot;username&quot;)</value>
      <webElementGuid>ff627bf5-280e-40db-9783-32fdfeadc8e2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;page-template-default page page-id-9 wp-custom-logo wp-embed-responsive theme-storefront woocommerce-account woocommerce-page woocommerce-demo-store woocommerce-js woocommerce-multi-currency-INR storefront-full-width-content storefront-secondary-navigation storefront-align-wide left-sidebar woocommerce-active sf-input-focused&quot;]</value>
      <webElementGuid>9abe2ea8-4f6f-4e3e-8ba4-2fb46ee2ad95</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//body</value>
      <webElementGuid>86f33fa2-75b1-499c-ab05-5cffe85be1ba</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//body[(text() = concat(&quot;




	
	

				Skip to navigation
		Skip to content
				
					
					
				My account
Checkout
Cart
			
						
				
	Search for:
	
	Search
	

			
					
		Menu
			Home Decor – Items &amp; Gifts

	Showpieces &amp; Figurines
	
		Musical Showpiece
		Spiritual figurines
		Vintage Decor
		Table Organizer
		Collectibles
	

	Wall Decor
	
		Wall hanging
		Spiritual Wall hanging
		Wall Art
		Wall panels
	

	Home Accents
	
		Photo frame
		Diffuser / Burner
	

	Lamps &amp; Lightings
	Clock
	Key Holders


Handmade Furnitures

	Bamboo Furniture
	
		Bamboo Chair
		Bamboo Mudha
		Bamboo Tables
		Bamboo Shelf / Rack
	

	Bamboo Laundry &amp; Organizer Baskets
	Natural Mudha
	Pidha stools
	Iron Stools Frame
	Cane Baskets
	Sofa chair / Long chair
	Wooden Furnitures


Cane Furniture
Outdoor Furniture
Hotel &amp; Restaurant Furniture
Mudha

	Mudha Stools
	Mudha chairs
	Mudha Table


Furnishings

	Cushions
	Placemats &amp; Runners
	Bedsheets
	
		Single Bedsheets
		Double Bedsheet
	

	Blankets &amp; Quilts
	Tapestry
	
		Single Tapestry
		Round Tapestry
		Double Tapestry
	

	Bamboo Storage Basket and Utility Baskets


Ladies Bags

	handbags
	Shoulder bags
	Sling bags
	clutches
	Combo Bags
	mobile pouch / potli bag


Under 500
Home Decor – Items &amp; GiftsExpand child menu

	Showpieces &amp; FigurinesExpand child menu
	
		Musical Showpiece
		Spiritual figurines
		Vintage Decor
		Table Organizer
		Collectibles
	

	Wall DecorExpand child menu
	
		Wall hanging
		Spiritual Wall hanging
		Wall Art
		Wall panels
	

	Home AccentsExpand child menu
	
		Photo frame
		Diffuser / Burner
	

	Lamps &amp; Lightings
	Clock
	Key Holders


Handmade FurnituresExpand child menu

	Bamboo FurnitureExpand child menu
	
		Bamboo Chair
		Bamboo Mudha
		Bamboo Tables
		Bamboo Shelf / Rack
	

	Bamboo Laundry &amp; Organizer Baskets
	Natural Mudha
	Pidha stools
	Iron Stools Frame
	Cane Baskets
	Sofa chair / Long chair
	Wooden Furnitures


Cane Furniture
Outdoor Furniture
Hotel &amp; Restaurant Furniture
MudhaExpand child menu

	Mudha Stools
	Mudha chairs
	Mudha Table


FurnishingsExpand child menu

	Cushions
	Placemats &amp; Runners
	BedsheetsExpand child menu
	
		Single Bedsheets
		Double Bedsheet
	

	Blankets &amp; Quilts
	TapestryExpand child menu
	
		Single Tapestry
		Round Tapestry
		Double Tapestry
	

	Bamboo Storage Basket and Utility Baskets


Ladies BagsExpand child menu

	handbags
	Shoulder bags
	Sling bags
	clutches
	Combo Bags
	mobile pouch / potli bag


Under 500
		
				
			
										
								₹0.00 0 items
			
		
					
			
				

	No products in the cart.


			
		
			
	

	Handicrafts / My account
	
		

		
	
		

			                        
                                                        
                                
                                    
                                
                            
                        
                    

			
			My account		
				
			

		Login

		

			
			
				Username or email address *
							
			
				Password *
				
			

			
			
				
					 Remember me
				
								Log in
			
			
				Lost your password?
			

			
		



					
		

		
	


		
	

	
	
		

							
									
						
Get in touch
 Address :
SRS 110, Nasirpur Rd, near Palam, near Dwarka, Main Road, New Delhi, Delhi 110045

 E-mail id info@craferia.com 
 Call +91 8373915568 ,+91 9354367361					
											
						
INFORMATION


About Us 



Contact us 



Privacy Policy 



Term &amp; Condition

					
											
						
Useful Links


Blog 



Mudha Furnitures 



Corporate Gifts

					
											
						
Follow us

Facebook

Instagram

YouTube

Google

Pinterest
					
									
						
			© Handicrafts Online, Indian Handicraft Items, Handmade in India - Craferia 2024
							
				Built with Storefront &amp; WooCommerce.					
				
			
									
						My Account					
									
						Search			
				
	Search for:
	
	Search
	

			
								
									
												Cart				0
			
		
							
							
		
		
		
	

	


.br_alabel .br_tooltip{display:none;}
                .br_alabel.berocket_alabel_id_27820 > span {
                color: white; display: flex; display: -webkit-box;
display: -ms-flexbox; position: relative; right: 0;text-align: center;
                }
                .br_alabel.berocket_alabel_id_27820 > span i.template-i-before {
                display: block;height: 0;position: absolute;width: 0;
                }
                .br_alabel.berocket_alabel_id_27820 > span i.template-i {
                background-color: transparent;display: block;line-height: 30px;position: absolute;z-index: 99;
                }
                .br_alabel.berocket_alabel_id_27820 > span i.template-i-after {
                display: block;height: 0;position: absolute;width: 0;
                }
                .br_alabel.berocket_alabel_id_27820 > span i.template-span-before {
                display: block;height: 0;position: absolute;width: 0;
                }div.br_alabel.berocket_alabel_id_27820{top:-10px;left:-10px;z-index:500;}div.br_alabel.berocket_alabel_id_27820 > span{height: 35px;width: 60px;background-color:#d03813;color:#ffffff;border-radius:3px;line-height:1.2em;font-size:14px;padding-left: 0px; padding-right: 0px; padding-top: 1px; padding-bottom: 0px; margin-left: -10px; margin-right: -10px; margin-top: -10px; margin-bottom: -10px; }
                .br_alabel.berocket_alabel_id_27823 > span {
                color: white; display: flex; display: -webkit-box;
display: -ms-flexbox; position: relative; right: 0;text-align: center;
                }
                .br_alabel.berocket_alabel_id_27823 > span i.template-i-before {
                display: block;height: 0;position: absolute;width: 0;
                }
                .br_alabel.berocket_alabel_id_27823 > span i.template-i {
                background-color: transparent;display: block;line-height: 30px;position: absolute;z-index: 99;
                }
                .br_alabel.berocket_alabel_id_27823 > span i.template-i-after {
                display: block;height: 0;position: absolute;width: 0;
                }
                .br_alabel.berocket_alabel_id_27823 > span i.template-span-before {
                display: block;height: 0;position: absolute;width: 0;
                }div.br_alabel.berocket_alabel_id_27823{top:-10px;z-index:500;}div.br_alabel.berocket_alabel_id_27823 > span{height: 29px;width: 55px;background-color:#d03813;color:#ffffff;border-radius:3px;line-height:0.9em;font-size:14px;padding-left: 0px; padding-right: 0px; padding-top: 0px; padding-bottom: 0px; margin-left: auto; margin-right: auto;margin-top: -32px; margin-bottom: 0px; }
                .br_alabel.berocket_alabel_id_28035 > span {
                color: white; display: flex; display: -webkit-box;
display: -ms-flexbox; position: relative; right: 0;text-align: center;
                }
                .br_alabel.berocket_alabel_id_28035 > span i.template-i-before {
                display: block;height: 0;position: absolute;width: 0;
                }
                .br_alabel.berocket_alabel_id_28035 > span i.template-i {
                background-color: transparent;display: block;line-height: 30px;position: absolute;z-index: 99;
                }
                .br_alabel.berocket_alabel_id_28035 > span i.template-i-after {
                display: block;height: 0;position: absolute;width: 0;
                }
                .br_alabel.berocket_alabel_id_28035 > span i.template-span-before {
                display: block;height: 0;position: absolute;width: 0;
                }div.br_alabel.berocket_alabel_id_28035{top:-10px;right:-10px;z-index:500;}div.br_alabel.berocket_alabel_id_28035 > span{height: 30px;width: 92px;background-color:#f2c51f;color:#ffffff;border-radius:3px;line-height:1.2em;font-size:12px;padding-left: 0px; padding-right: 0px; padding-top: 0px; padding-bottom: 0px; margin-left: -10px; margin-right: -10px; margin-top: -10px; margin-bottom: -10px; }- Free shipping is now available for all purchases of *CANE FURNITURE  items Dismiss{&quot;@context&quot;:&quot;https:\/\/schema.org\/&quot;,&quot;@type&quot;:&quot;BreadcrumbList&quot;,&quot;itemListElement&quot;:[{&quot;@type&quot;:&quot;ListItem&quot;,&quot;position&quot;:1,&quot;item&quot;:{&quot;name&quot;:&quot;Handicrafts&quot;,&quot;@id&quot;:&quot;https:\/\/craferia.com&quot;}},{&quot;@type&quot;:&quot;ListItem&quot;,&quot;position&quot;:2,&quot;item&quot;:{&quot;name&quot;:&quot;My account&quot;,&quot;@id&quot;:&quot;https:\/\/craferia.com\/my-account\/&quot;}}]}
	
		
		
							
						×
					
	

	
		(function () {
			var c = document.body.className;
			c = c.replace(/woocommerce-no-js/, &quot; , &quot;'&quot; , &quot;woocommerce-js&quot; , &quot;'&quot; , &quot;);
			document.body.className = c;
		})();
	
	

var wc_add_to_cart_params = {&quot;ajax_url&quot;:&quot;\/wp-admin\/admin-ajax.php&quot;,&quot;wc_ajax_url&quot;:&quot;\/?wc-ajax=%%endpoint%%&quot;,&quot;i18n_view_cart&quot;:&quot;View cart&quot;,&quot;cart_url&quot;:&quot;https:\/\/craferia.com\/cart\/&quot;,&quot;is_cart&quot;:&quot;&quot;,&quot;cart_redirect_after_add&quot;:&quot;no&quot;};





var woocommerce_params = {&quot;ajax_url&quot;:&quot;\/wp-admin\/admin-ajax.php&quot;,&quot;wc_ajax_url&quot;:&quot;\/?wc-ajax=%%endpoint%%&quot;};



var wc_cart_fragments_params = {&quot;ajax_url&quot;:&quot;\/wp-admin\/admin-ajax.php&quot;,&quot;wc_ajax_url&quot;:&quot;\/?wc-ajax=%%endpoint%%&quot;,&quot;cart_hash_key&quot;:&quot;wc_cart_hash_b3b9d17cdf5b4420c5a61701c182be0d&quot;,&quot;fragment_name&quot;:&quot;wc_fragments_b3b9d17cdf5b4420c5a61701c182be0d&quot;,&quot;request_timeout&quot;:&quot;5000&quot;};



var storefrontScreenReaderText = {&quot;expand&quot;:&quot;Expand child menu&quot;,&quot;collapse&quot;:&quot;Collapse child menu&quot;};








id(&quot;username&quot;)&quot;) or . = concat(&quot;




	
	

				Skip to navigation
		Skip to content
				
					
					
				My account
Checkout
Cart
			
						
				
	Search for:
	
	Search
	

			
					
		Menu
			Home Decor – Items &amp; Gifts

	Showpieces &amp; Figurines
	
		Musical Showpiece
		Spiritual figurines
		Vintage Decor
		Table Organizer
		Collectibles
	

	Wall Decor
	
		Wall hanging
		Spiritual Wall hanging
		Wall Art
		Wall panels
	

	Home Accents
	
		Photo frame
		Diffuser / Burner
	

	Lamps &amp; Lightings
	Clock
	Key Holders


Handmade Furnitures

	Bamboo Furniture
	
		Bamboo Chair
		Bamboo Mudha
		Bamboo Tables
		Bamboo Shelf / Rack
	

	Bamboo Laundry &amp; Organizer Baskets
	Natural Mudha
	Pidha stools
	Iron Stools Frame
	Cane Baskets
	Sofa chair / Long chair
	Wooden Furnitures


Cane Furniture
Outdoor Furniture
Hotel &amp; Restaurant Furniture
Mudha

	Mudha Stools
	Mudha chairs
	Mudha Table


Furnishings

	Cushions
	Placemats &amp; Runners
	Bedsheets
	
		Single Bedsheets
		Double Bedsheet
	

	Blankets &amp; Quilts
	Tapestry
	
		Single Tapestry
		Round Tapestry
		Double Tapestry
	

	Bamboo Storage Basket and Utility Baskets


Ladies Bags

	handbags
	Shoulder bags
	Sling bags
	clutches
	Combo Bags
	mobile pouch / potli bag


Under 500
Home Decor – Items &amp; GiftsExpand child menu

	Showpieces &amp; FigurinesExpand child menu
	
		Musical Showpiece
		Spiritual figurines
		Vintage Decor
		Table Organizer
		Collectibles
	

	Wall DecorExpand child menu
	
		Wall hanging
		Spiritual Wall hanging
		Wall Art
		Wall panels
	

	Home AccentsExpand child menu
	
		Photo frame
		Diffuser / Burner
	

	Lamps &amp; Lightings
	Clock
	Key Holders


Handmade FurnituresExpand child menu

	Bamboo FurnitureExpand child menu
	
		Bamboo Chair
		Bamboo Mudha
		Bamboo Tables
		Bamboo Shelf / Rack
	

	Bamboo Laundry &amp; Organizer Baskets
	Natural Mudha
	Pidha stools
	Iron Stools Frame
	Cane Baskets
	Sofa chair / Long chair
	Wooden Furnitures


Cane Furniture
Outdoor Furniture
Hotel &amp; Restaurant Furniture
MudhaExpand child menu

	Mudha Stools
	Mudha chairs
	Mudha Table


FurnishingsExpand child menu

	Cushions
	Placemats &amp; Runners
	BedsheetsExpand child menu
	
		Single Bedsheets
		Double Bedsheet
	

	Blankets &amp; Quilts
	TapestryExpand child menu
	
		Single Tapestry
		Round Tapestry
		Double Tapestry
	

	Bamboo Storage Basket and Utility Baskets


Ladies BagsExpand child menu

	handbags
	Shoulder bags
	Sling bags
	clutches
	Combo Bags
	mobile pouch / potli bag


Under 500
		
				
			
										
								₹0.00 0 items
			
		
					
			
				

	No products in the cart.


			
		
			
	

	Handicrafts / My account
	
		

		
	
		

			                        
                                                        
                                
                                    
                                
                            
                        
                    

			
			My account		
				
			

		Login

		

			
			
				Username or email address *
							
			
				Password *
				
			

			
			
				
					 Remember me
				
								Log in
			
			
				Lost your password?
			

			
		



					
		

		
	


		
	

	
	
		

							
									
						
Get in touch
 Address :
SRS 110, Nasirpur Rd, near Palam, near Dwarka, Main Road, New Delhi, Delhi 110045

 E-mail id info@craferia.com 
 Call +91 8373915568 ,+91 9354367361					
											
						
INFORMATION


About Us 



Contact us 



Privacy Policy 



Term &amp; Condition

					
											
						
Useful Links


Blog 



Mudha Furnitures 



Corporate Gifts

					
											
						
Follow us

Facebook

Instagram

YouTube

Google

Pinterest
					
									
						
			© Handicrafts Online, Indian Handicraft Items, Handmade in India - Craferia 2024
							
				Built with Storefront &amp; WooCommerce.					
				
			
									
						My Account					
									
						Search			
				
	Search for:
	
	Search
	

			
								
									
												Cart				0
			
		
							
							
		
		
		
	

	


.br_alabel .br_tooltip{display:none;}
                .br_alabel.berocket_alabel_id_27820 > span {
                color: white; display: flex; display: -webkit-box;
display: -ms-flexbox; position: relative; right: 0;text-align: center;
                }
                .br_alabel.berocket_alabel_id_27820 > span i.template-i-before {
                display: block;height: 0;position: absolute;width: 0;
                }
                .br_alabel.berocket_alabel_id_27820 > span i.template-i {
                background-color: transparent;display: block;line-height: 30px;position: absolute;z-index: 99;
                }
                .br_alabel.berocket_alabel_id_27820 > span i.template-i-after {
                display: block;height: 0;position: absolute;width: 0;
                }
                .br_alabel.berocket_alabel_id_27820 > span i.template-span-before {
                display: block;height: 0;position: absolute;width: 0;
                }div.br_alabel.berocket_alabel_id_27820{top:-10px;left:-10px;z-index:500;}div.br_alabel.berocket_alabel_id_27820 > span{height: 35px;width: 60px;background-color:#d03813;color:#ffffff;border-radius:3px;line-height:1.2em;font-size:14px;padding-left: 0px; padding-right: 0px; padding-top: 1px; padding-bottom: 0px; margin-left: -10px; margin-right: -10px; margin-top: -10px; margin-bottom: -10px; }
                .br_alabel.berocket_alabel_id_27823 > span {
                color: white; display: flex; display: -webkit-box;
display: -ms-flexbox; position: relative; right: 0;text-align: center;
                }
                .br_alabel.berocket_alabel_id_27823 > span i.template-i-before {
                display: block;height: 0;position: absolute;width: 0;
                }
                .br_alabel.berocket_alabel_id_27823 > span i.template-i {
                background-color: transparent;display: block;line-height: 30px;position: absolute;z-index: 99;
                }
                .br_alabel.berocket_alabel_id_27823 > span i.template-i-after {
                display: block;height: 0;position: absolute;width: 0;
                }
                .br_alabel.berocket_alabel_id_27823 > span i.template-span-before {
                display: block;height: 0;position: absolute;width: 0;
                }div.br_alabel.berocket_alabel_id_27823{top:-10px;z-index:500;}div.br_alabel.berocket_alabel_id_27823 > span{height: 29px;width: 55px;background-color:#d03813;color:#ffffff;border-radius:3px;line-height:0.9em;font-size:14px;padding-left: 0px; padding-right: 0px; padding-top: 0px; padding-bottom: 0px; margin-left: auto; margin-right: auto;margin-top: -32px; margin-bottom: 0px; }
                .br_alabel.berocket_alabel_id_28035 > span {
                color: white; display: flex; display: -webkit-box;
display: -ms-flexbox; position: relative; right: 0;text-align: center;
                }
                .br_alabel.berocket_alabel_id_28035 > span i.template-i-before {
                display: block;height: 0;position: absolute;width: 0;
                }
                .br_alabel.berocket_alabel_id_28035 > span i.template-i {
                background-color: transparent;display: block;line-height: 30px;position: absolute;z-index: 99;
                }
                .br_alabel.berocket_alabel_id_28035 > span i.template-i-after {
                display: block;height: 0;position: absolute;width: 0;
                }
                .br_alabel.berocket_alabel_id_28035 > span i.template-span-before {
                display: block;height: 0;position: absolute;width: 0;
                }div.br_alabel.berocket_alabel_id_28035{top:-10px;right:-10px;z-index:500;}div.br_alabel.berocket_alabel_id_28035 > span{height: 30px;width: 92px;background-color:#f2c51f;color:#ffffff;border-radius:3px;line-height:1.2em;font-size:12px;padding-left: 0px; padding-right: 0px; padding-top: 0px; padding-bottom: 0px; margin-left: -10px; margin-right: -10px; margin-top: -10px; margin-bottom: -10px; }- Free shipping is now available for all purchases of *CANE FURNITURE  items Dismiss{&quot;@context&quot;:&quot;https:\/\/schema.org\/&quot;,&quot;@type&quot;:&quot;BreadcrumbList&quot;,&quot;itemListElement&quot;:[{&quot;@type&quot;:&quot;ListItem&quot;,&quot;position&quot;:1,&quot;item&quot;:{&quot;name&quot;:&quot;Handicrafts&quot;,&quot;@id&quot;:&quot;https:\/\/craferia.com&quot;}},{&quot;@type&quot;:&quot;ListItem&quot;,&quot;position&quot;:2,&quot;item&quot;:{&quot;name&quot;:&quot;My account&quot;,&quot;@id&quot;:&quot;https:\/\/craferia.com\/my-account\/&quot;}}]}
	
		
		
							
						×
					
	

	
		(function () {
			var c = document.body.className;
			c = c.replace(/woocommerce-no-js/, &quot; , &quot;'&quot; , &quot;woocommerce-js&quot; , &quot;'&quot; , &quot;);
			document.body.className = c;
		})();
	
	

var wc_add_to_cart_params = {&quot;ajax_url&quot;:&quot;\/wp-admin\/admin-ajax.php&quot;,&quot;wc_ajax_url&quot;:&quot;\/?wc-ajax=%%endpoint%%&quot;,&quot;i18n_view_cart&quot;:&quot;View cart&quot;,&quot;cart_url&quot;:&quot;https:\/\/craferia.com\/cart\/&quot;,&quot;is_cart&quot;:&quot;&quot;,&quot;cart_redirect_after_add&quot;:&quot;no&quot;};





var woocommerce_params = {&quot;ajax_url&quot;:&quot;\/wp-admin\/admin-ajax.php&quot;,&quot;wc_ajax_url&quot;:&quot;\/?wc-ajax=%%endpoint%%&quot;};



var wc_cart_fragments_params = {&quot;ajax_url&quot;:&quot;\/wp-admin\/admin-ajax.php&quot;,&quot;wc_ajax_url&quot;:&quot;\/?wc-ajax=%%endpoint%%&quot;,&quot;cart_hash_key&quot;:&quot;wc_cart_hash_b3b9d17cdf5b4420c5a61701c182be0d&quot;,&quot;fragment_name&quot;:&quot;wc_fragments_b3b9d17cdf5b4420c5a61701c182be0d&quot;,&quot;request_timeout&quot;:&quot;5000&quot;};



var storefrontScreenReaderText = {&quot;expand&quot;:&quot;Expand child menu&quot;,&quot;collapse&quot;:&quot;Collapse child menu&quot;};








id(&quot;username&quot;)&quot;))]</value>
      <webElementGuid>c41c2021-ac31-4892-bf63-94f5acc51167</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
