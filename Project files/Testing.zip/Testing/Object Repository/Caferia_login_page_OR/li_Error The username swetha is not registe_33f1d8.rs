<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>li_Error The username swetha is not registe_33f1d8</name>
   <tag></tag>
   <elementGuidId>a32327e5-6385-4503-b896-c74efeba4ce8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='content']/div/div/ul/li</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>ul.woocommerce-error > li</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>li</value>
      <webElementGuid>cddf4c50-0319-4885-bbef-a534d7fca794</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
			Error: The username swetha is not registered on this site. If you are unsure of your username, try your email address instead.		</value>
      <webElementGuid>90c8dad1-47e1-43c8-840a-b6e34c99ef38</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;content&quot;)/div[@class=&quot;col-full&quot;]/div[@class=&quot;woocommerce&quot;]/ul[@class=&quot;woocommerce-error&quot;]/li[1]</value>
      <webElementGuid>b1789f45-c802-4901-a059-6a5ac7006d04</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='content']/div/div/ul/li</value>
      <webElementGuid>b6bf83eb-31dc-4b36-9c23-658f03c2fb37</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='/'])[1]/following::li[1]</value>
      <webElementGuid>1a89009b-c4a4-4638-bd69-8849e92017d7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Handicrafts'])[1]/following::li[1]</value>
      <webElementGuid>d4417339-d885-4002-b6a0-30227525c5f1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='The username']/parent::*</value>
      <webElementGuid>ed19337a-0f9a-4df6-999c-4dcbd5dad2f9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/ul/li</value>
      <webElementGuid>b6d41681-e46c-4d08-b1ec-9c497f175ccd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//li[(text() = '
			Error: The username swetha is not registered on this site. If you are unsure of your username, try your email address instead.		' or . = '
			Error: The username swetha is not registered on this site. If you are unsure of your username, try your email address instead.		')]</value>
      <webElementGuid>e7b3c16a-d75b-44ed-ac1d-c18276b9bbec</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
